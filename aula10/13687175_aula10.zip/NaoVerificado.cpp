#include "NaoVerificado.h"

NaoVerificado::NaoVerificado() : runtime_error("Canal nao verificado") {};