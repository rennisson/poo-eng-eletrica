#ifndef VIDEOCURTO_H
#define VIDEOCURTO_H

#include "Video.h"

class VideoCurto: public Video {
public:
    VideoCurto(string nome, int duracao);
    ~VideoCurto();

private:

};

#endif